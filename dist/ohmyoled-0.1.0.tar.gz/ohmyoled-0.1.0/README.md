# ohmyoled

# Prerequistes:

You will have to install git

```
#!/bin/bash
sudo apt install git -y 
```

Clone the repo
```
git clone https://github.com/TheFinalJoke/ohmyoled.git
```

Run the Install Script
```
#!/bin/bash
chmod 755 install.sh
sudo ./install.sh
```
